__version__ = "5.6.3"

if __name__ == "__main__":
    print(__version__)
