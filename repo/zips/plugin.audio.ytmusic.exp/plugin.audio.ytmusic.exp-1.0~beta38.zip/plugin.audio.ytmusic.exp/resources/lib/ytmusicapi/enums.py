from enum import Enum


class ResponseStatus(str, Enum):
    SUCCEEDED = "STATUS_SUCCEEDED"
